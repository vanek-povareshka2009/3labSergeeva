package org.example;

public class MyArraySizeException extends RuntimeException{
    public MyArraySizeException(String msg) {
        super(msg);
    }

}
